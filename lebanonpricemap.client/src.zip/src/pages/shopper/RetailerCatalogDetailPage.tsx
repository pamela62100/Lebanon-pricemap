import { useParams, useNavigate } from 'react-router-dom';
import { useMemo } from 'react';
import { MOCK_STORES, getEnrichedPriceEntries } from '@/api/mockData';
import { PriceResultCard } from '@/components/cards/PriceResultCard';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/cards/Card';
import { cn } from '@/lib/utils';

export function RetailerCatalogDetailPage() {
  const { storeId } = useParams<{ storeId: string }>();
  const navigate = useNavigate();
  
  const store = useMemo(() => {
    return MOCK_STORES.find(s => s.id === storeId);
  }, [storeId]);

  const entries = useMemo(() => {
    return getEnrichedPriceEntries().filter(pe => pe.storeId === storeId && pe.source === 'official');
  }, [storeId]);

  if (!store) {
    return (
      <div className="p-12 text-center">
        <h2 className="text-2xl font-black text-text-main">Store not found</h2>
        <button 
          onClick={() => navigate('/app/catalog')}
          className="mt-4 text-primary font-bold underline"
        >
          Back to list
        </button>
      </div>
    );
  }

  const initials = store.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="min-h-full">
      {/* Store Hero */}
      <div className="relative h-64 bg-gradient-to-br from-primary/20 via-bg-muted to-bg-base overflow-hidden border-b border-border-primary/20">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
        
        <div className="max-w-7xl mx-auto px-8 md:px-12 h-full flex flex-col justify-end pb-10 relative z-10">
          <div className="flex items-end gap-8 translate-y-4">
            <div className="w-32 h-32 rounded-3xl bg-white border-4 border-white shadow-2xl flex items-center justify-center overflow-hidden shrink-0">
               {store.logoUrl ? (
                 <img src={store.logoUrl} alt={store.name} className="w-24 h-24 object-contain" />
               ) : (
                 <span className="font-serif font-black text-4xl text-primary italic">{initials}</span>
               )}
            </div>
            
            <div className="mb-4">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-black text-text-main leading-none">{store.name}</h1>
                <span className="material-symbols-outlined text-blue-500">verified</span>
              </div>
              <div className="flex items-center gap-4 text-sm font-bold text-text-sub uppercase tracking-widest">
                <span>{store.chain || 'Independent'}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-border-primary/30" />
                <span>{store.district}, {store.city}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 md:px-12 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Left Column: Info & Stats */}
        <div className="space-y-8">
           <Card className="p-6 border-primary/20 bg-primary/5">
              <h4 className="text-[10px] font-black text-primary uppercase tracking-[0.3em] mb-4">Official Exchange Rate</h4>
              <p className="text-4xl font-black text-text-main mb-1">
                LBP {store.internalRateLbp.toLocaleString()}
              </p>
              <p className="text-[10px] text-text-muted font-bold tracking-widest uppercase">Per 1.00 USD</p>
           </Card>

           <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 bg-bg-surface">
                <p className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-1">Trust Score</p>
                <p className="text-2xl font-black text-green-500">{store.trustScore}%</p>
              </Card>
              <Card className="p-4 bg-bg-surface">
                <p className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-1">Live Records</p>
                <p className="text-2xl font-black text-text-main">{entries.length}</p>
              </Card>
           </div>

           <Card className="p-6">
              <h4 className="text-[10px] font-black text-text-main uppercase tracking-widest mb-4">About this Retailer</h4>
              <p className="text-sm text-text-sub font-medium leading-relaxed">
                {store.name} is a verified partner of WeinArkhas. All prices shown in this catalog are officially documented and updated directly by the store management to ensure maximum transparency for shoppers.
              </p>
              <div className="mt-6 space-y-3">
                 <div className="flex items-center gap-3 text-xs font-bold text-text-main">
                    <span className="material-symbols-outlined text-primary text-[18px]">power</span>
                    <span>Power Status: <span className="text-green-500 capitalize">{store.powerStatus}</span></span>
                 </div>
                 <div className="flex items-center gap-3 text-xs font-bold text-text-main">
                    <span className="material-symbols-outlined text-primary text-[18px]">travel_explore</span>
                    <span>Region: {store.region}</span>
                 </div>
              </div>
           </Card>
        </div>

        {/* Right Column: List of items */}
        <div className="lg:col-span-2">
           <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-black text-text-main">Official Store Catalog</h2>
              <div className="text-[10px] font-black text-text-muted uppercase tracking-widest">
                {entries.length} items found
              </div>
           </div>

           <div className="space-y-6">
              {entries.length > 0 ? (
                <AnimatePresence mode="popLayout">
                  {entries.map((entry: any, i: number) => (
                    <PriceResultCard key={entry.id} entry={entry} index={i} />
                  ))}
                </AnimatePresence>
              ) : (
                <div className="py-20 text-center border border-dashed border-border-primary/40 rounded-3xl bg-bg-surface/30">
                  <span className="material-symbols-outlined text-border-primary/40 text-[48px] mb-3">inventory_2</span>
                  <p className="text-sm font-bold text-text-muted">No official records found for this store yet.</p>
                </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
}
