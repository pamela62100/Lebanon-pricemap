import { useMemo } from 'react';
import { MOCK_STORES } from '@/api/mockData';
import { StoreCard } from '@/components/cards/StoreCard';
import { motion } from 'framer-motion';

export function RetailerCatalogPage() {
  const verifiedRetailers = useMemo(() => {
    return MOCK_STORES.filter(s => s.isVerifiedRetailer);
  }, []);

  return (
    <div className="p-8 md:p-12 max-w-7xl mx-auto min-h-full">
      <header className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent to-border-primary/30" />
          <span className="text-[11px] font-black text-primary uppercase tracking-[0.4em] px-4">Verified Network</span>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent to-border-primary/30" />
        </div>
        
        <h1 className="font-sans text-5xl font-black text-text-main leading-tight mb-4 text-center">
          Official Partner<br />Catalogs.
        </h1>
        <p className="text-text-muted text-base font-medium max-w-2xl mx-auto text-center">
          Browse verified price lists directly from Lebanon's leading supermarkets. Documented, accurate, and updated officially by the retailers.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {verifiedRetailers.map((store, i) => (
          <StoreCard key={store.id} store={store} index={i} />
        ))}
      </div>

      {verifiedRetailers.length === 0 && (
        <div className="py-32 text-center border border-dashed border-border-primary/40 rounded-3xl bg-bg-surface/30 backdrop-blur-sm">
          <span className="material-symbols-outlined text-border-primary text-[64px] mb-4 opacity-40">storefront</span>
          <p className="text-lg font-bold text-text-muted">No verified retailers found in this area.</p>
        </div>
      )}
    </div>
  );
}
