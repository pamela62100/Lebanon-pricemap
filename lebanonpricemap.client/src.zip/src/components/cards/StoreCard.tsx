import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import type { Store } from '@/types';
import { Card } from './Card';
import { cn } from '@/lib/utils';

interface StoreCardProps {
  store: Store;
  index: number;
}

export const StoreCard = ({ store, index }: StoreCardProps) => {
  const navigate = useNavigate();
  const initials = store.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      onClick={() => navigate(`/app/catalog/${store.id}`)}
      className="cursor-pointer group"
    >
      <Card className="p-0 overflow-hidden border-border-primary/20 hover:border-primary/40 transition-all bg-bg-surface/50 backdrop-blur-sm shadow-xl hover:shadow-primary/5">
        <div className="h-32 bg-gradient-to-br from-primary/10 via-bg-muted to-bg-surface relative flex items-center justify-center overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
          <div className="absolute -bottom-10 -left-10 w-24 h-24 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
          
          {store.logoUrl ? (
            <img 
              src={store.logoUrl} 
              alt={store.name} 
              className="w-20 h-20 object-contain drop-shadow-md group-hover:scale-110 transition-transform duration-500"
              onError={(e) => {
                (e.target as HTMLImageElement).src = ''; // Fallback to initials
                (e.target as HTMLImageElement).className = 'hidden';
              }}
            />
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-white border border-border-primary/5 shadow-inner flex items-center justify-center font-serif font-black text-2xl italic text-primary group-hover:scale-110 transition-transform">
              {initials}
            </div>
          )}
          
          <div className="absolute top-3 right-3 flex items-center gap-1 bg-white/80 backdrop-blur-sm border border-blue-500/20 px-2 py-1 rounded-full shadow-sm">
            <span className="material-symbols-outlined text-[14px] text-blue-500">verified</span>
            <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest leading-none mt-0.5">Partner</span>
          </div>
        </div>
        
        <div className="p-5 border-t border-border-primary/10">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-sans text-lg font-black text-text-main group-hover:text-primary transition-colors leading-tight truncate mr-2">
              {store.name}
            </h3>
            <div className="flex items-center gap-1 bg-green-500/5 px-2 py-0.5 rounded border border-green-500/10 shrink-0">
               <span className="material-symbols-outlined text-[12px] text-green-500">verified_user</span>
               <span className="text-[10px] font-black text-green-500">{store.trustScore}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-[10px] font-bold text-text-muted uppercase tracking-wider">
            <span className="material-symbols-outlined text-[14px]">location_on</span>
            {store.district}, {store.city}
          </div>
          
          <div className="mt-4 pt-4 border-t border-border-soft flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[9px] font-black text-text-muted uppercase tracking-widest">Rate (USD)</span>
              <span className="text-xs font-black text-text-main">1$ = {store.internalRateLbp.toLocaleString()}</span>
            </div>
            <button className="h-8 px-4 bg-bg-muted border border-border-primary/20 text-[9px] font-black text-text-sub uppercase tracking-widest rounded-md group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-all">
              View Catalog
            </button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};
