import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import type { PriceEntry } from '@/types';
import { formatLBP, timeAgo, cn } from '@/lib/utils';
import { useExchangeRateStore } from '@/store/useExchangeRateStore';
import { useCartStore } from '@/store/useCartStore';
import { useLocationStore } from '@/store/useLocationStore';
import { useToastStore } from '@/store/useToastStore';
import { useRouteDialog } from '@/hooks/useRouteDialog';
import { distanceKm, formatDistance } from '@/lib/distanceUtils';
import { Card } from './Card';


interface PriceResultCardProps {
  entry: PriceEntry;
  index: number;
}

const PriceResultCardBase = ({ entry, index }: PriceResultCardProps) => {
  const navigate = useNavigate();
  const { rateLbpPerUsd } = useExchangeRateStore();
  const { lat, lng } = useLocationStore();
  const addItem = useCartStore(s => s.addItem);
  const addToast = useToastStore(s => s.addToast);
  const { open } = useRouteDialog();

  const usdPrice = (entry.priceLbp / rateLbpPerUsd).toFixed(2);
  const storeRate = entry.store?.internalRateLbp ?? rateLbpPerUsd;
  const rateDiff = storeRate - rateLbpPerUsd;
  const isRateFair = Math.abs(rateDiff) < 500;

  const showsFridge = entry.product?.category === 'Dairy' || entry.product?.category === 'Meat';
  const powerStatus = entry.store?.powerStatus ?? 'stable';

  const distance = lat && lng && entry.store?.latitude && entry.store?.longitude
    ? distanceKm(lat, lng, entry.store.latitude, entry.store.longitude)
    : null;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addItem(entry.productId);
    addToast(`${entry.product?.name ?? 'Item'} added ✓`, 'success');
  };

  const storeInitials = entry.store?.name?.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'ST';

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      onClick={() => navigate(`/app/price/${entry.id}`)}
    >
      <Card className="relative group cursor-pointer p-2">
        {/* Left Avatar + Verified */}
        <div className="flex gap-8">
          <div className="flex flex-col items-center gap-3 shrink-0">
            <div className={cn(
              "w-14 h-14 rounded-full border border-border-primary/10 flex items-center justify-center font-serif font-black text-sm italic text-primary transition-all group-hover:bg-primary group-hover:text-white"
            )}>
              {storeInitials}
            </div>
            {entry.source === 'official' ? (
              <div className="flex flex-col items-center gap-1">
                <span className="material-symbols-outlined text-blue-500 text-[18px]">verified</span>
                <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest text-center leading-tight">Official<br/>Source</span>
              </div>
            ) : entry.status === 'verified' ? (
              <div className="flex flex-col items-center gap-1">
                <span className="material-symbols-outlined text-green-500 text-[18px]">verified_user</span>
                <span className="text-[8px] font-black text-green-500 uppercase tracking-widest text-center leading-tight">Verified<br/>Community</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1 opacity-60">
                <span className="material-symbols-outlined text-text-muted text-[18px]">pending_actions</span>
                <span className="text-[8px] font-black text-text-muted uppercase tracking-widest text-center leading-tight">Pending<br/>Review</span>
              </div>
            )}
            {entry.source === 'community' && entry.submitterTrustScore && (
              <div className="mt-2 flex flex-col items-center">
                <div className="w-8 h-1 bg-border-soft rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all",
                      entry.submitterTrustScore > 80 ? "bg-green-500" : entry.submitterTrustScore > 50 ? "bg-orange-400" : "bg-red-400"
                    )}
                    style={{ width: `${entry.submitterTrustScore}%` }}
                  />
                </div>
                <span className="text-[7px] font-black text-text-muted mt-0.5 uppercase">Trust: {entry.submitterTrustScore}%</span>
              </div>
            )}
          </div>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-sans text-xl font-black text-text-main truncate leading-tight">
  {entry.store?.name}
</h3>
              <div className="text-right shrink-0 ml-4">
                <p className="text-2xl font-black text-primary leading-none tabular-nums">
  {entry.priceLbp.toLocaleString()}
</p>
                <p className="text-[9px] font-black text-text-muted uppercase tracking-[0.3em] mt-1">
                  LBP
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-[10px] font-bold text-text-sub uppercase tracking-widest mb-4">
              <span>{entry.store?.district}</span>
              <span className="w-1 h-1 rounded-full bg-border-primary" />
              <span className="text-primary">{entry.product?.category}</span>
            </div>

            <div className="flex items-center gap-3 text-[9px] font-bold text-text-muted uppercase tracking-tighter">
              <span className="material-symbols-outlined text-[14px]">history</span>
              Captured {timeAgo(entry.createdAt)}
              {distance && (
                <>
                  <span className="w-1 h-1 rounded-full bg-border-primary/40" />
                  <span className="text-primary/70">{formatDistance(distance)} offset</span>
                </>
              )}
            </div>

            {/* Metadata strip */}
            {(showsFridge || !isRateFair) && (
              <div className="mt-3 pt-3 border-t border-border-soft flex flex-wrap gap-2">
                {showsFridge && (
                  <div className={cn(
                    "px-3 py-1 text-[9px] font-black uppercase tracking-widest border rounded-md",
                    powerStatus === 'stable'
                      ? "text-status-verified-text border-status-verified-text/20 bg-status-verified-text/5"
                      : "text-status-flagged-text border-status-flagged-text/20 bg-status-flagged-text/5"
                  )}>
                    {powerStatus === 'stable'
                      ? 'Cold Chain Protocol: Stable'
                      : 'Cold Chain Protocol: Compromised'}
                  </div>
                )}
                {!isRateFair && (
                  <div className="px-3 py-1 text-[9px] font-black text-primary uppercase tracking-widest border border-primary/20 bg-primary/5 rounded-md">
                    Warning: Higher Internal Store Rate
                  </div>
                )}
              </div>
            )}

            {/* Interactive Overlay */}
            <div className="mt-8 pt-6 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
              <div className="flex gap-4">
                <button
                  onClick={(e) => { e.stopPropagation(); open('report-price', { id: entry.id }); }}
                  className="text-[9px] font-black underline underline-offset-4 text-text-muted hover:text-red-600 transition-colors uppercase tracking-[0.2em]"
                >
                  FLAG_INACCURACY
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); open('report-reality', { storeId: entry.storeId, type: 'market' }); }}
                  className="text-[9px] font-black underline underline-offset-4 text-text-muted hover:text-primary transition-colors uppercase tracking-[0.2em]"
                >
                  REFINE_LOCATION_DATA
                </button>
                {entry.source === 'official' && (
                  <button
                    onClick={(e) => { e.stopPropagation(); navigate(`/app/catalog/${entry.storeId}`); }}
                    className="text-[9px] font-black underline underline-offset-4 text-primary hover:text-black transition-colors uppercase tracking-[0.2em]"
                  >
                    VIEW_STORE_CATALOG
                  </button>
                )}
              </div>

              <button
                onClick={handleAddToCart}
                className="h-11 px-8 bg-primary text-white text-[10px] font-bold uppercase tracking-[0.25em] hover:bg-black transition-all shadow-lg rounded-md"
              >
                Add to Collection
              </button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export const PriceResultCard = React.memo(PriceResultCardBase);