import axios, { InternalAxiosRequestConfig } from 'axios';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5223/api',
  headers: { 'Content-Type': 'application/json' },
});

client.interceptors.request.use((config: any) => {
  const token = localStorage.getItem('rakis_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('rakis_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default client;
