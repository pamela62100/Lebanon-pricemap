import { useParams, useNavigate } from 'react-router-dom';
import { useMemo } from 'react';
import { MOCK_STORES } from '@/api/mockData';
import { motion } from 'framer-motion';
import { Card } from '@/components/cards/Card';
import { StoreCatalogView } from '@/components/catalog/StoreCatalogView';

export function RetailerCatalogDetailPage() {
  const { storeId } = useParams<{ storeId: string }>();
  const navigate = useNavigate();

  const store = useMemo(() => MOCK_STORES.find(s => s.id === storeId), [storeId]);

  if (!store) {
    return (
      <div className="p-12 text-center">
        <h2 className="text-2xl font-black text-text-main">Store not found</h2>
        <button onClick={() => navigate('/app/catalog')} className="mt-4 text-primary font-bold underline">
          Back to list
        </button>
      </div>
    );
  }

  const initials = store.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="min-h-full">
      {/* Store Hero */}
      <div className="relative h-64 bg-gradient-to-br from-primary/20 via-bg-muted to-bg-base overflow-hidden border-b border-border-primary/20">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
        <div className="max-w-7xl mx-auto px-8 md:px-12 h-full flex flex-col justify-end pb-10 relative z-10">
          <div className="flex items-end gap-8 translate-y-4">
            <div className="w-32 h-32 rounded-3xl bg-white border-4 border-white shadow-2xl flex items-center justify-center overflow-hidden shrink-0">
              {store.logoUrl ? (
                <img src={store.logoUrl} alt={store.name} className="w-24 h-24 object-contain" />
              ) : (
                <span className="font-serif font-black text-4xl text-primary italic">{initials}</span>
              )}
            </div>
            <div className="mb-4">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-black text-text-main leading-none">{store.name}</h1>
                {store.isVerifiedRetailer && (
                  <span className="material-symbols-outlined text-blue-500 text-[28px]">verified</span>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm font-bold text-text-sub uppercase tracking-widest">
                <span>{store.chain || 'Independent'}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-border-primary/30" />
                <span>{store.district}, {store.city}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 md:px-12 py-12 grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Left Column: Info & Stats */}
        <div className="space-y-6">
          <Card className="p-6 border-primary/20 bg-primary/5">
            <h4 className="text-[10px] font-black text-primary uppercase tracking-[0.3em] mb-4">Store Rate</h4>
            <p className="text-3xl font-black text-text-main mb-1">
              {store.internalRateLbp.toLocaleString()}
            </p>
            <p className="text-[9px] text-text-muted font-bold tracking-widest uppercase">LBP per 1 USD</p>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <Card className="p-4 bg-bg-surface">
              <p className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-1">Trust</p>
              <p className="text-2xl font-black text-green-500">{store.trustScore}%</p>
            </Card>
            <Card className="p-4 bg-bg-surface">
              <p className="text-[9px] font-black text-text-muted uppercase tracking-widest mb-1">Status</p>
              <p className={`text-sm font-black capitalize ${
                store.powerStatus === 'stable' ? 'text-green-500' :
                store.powerStatus === 'unstable' ? 'text-amber-500' : 'text-red-500'
              }`}>{store.powerStatus}</p>
            </Card>
          </div>

          <Card className="p-5">
            <h4 className="text-[10px] font-black text-text-main uppercase tracking-widest mb-3">Location</h4>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-bold text-text-sub">
                <span className="material-symbols-outlined text-primary text-[16px]">location_on</span>
                {store.district}, {store.city}
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-text-sub">
                <span className="material-symbols-outlined text-primary text-[16px]">travel_explore</span>
                {store.region}
              </div>
            </div>
          </Card>

          {store.isVerifiedRetailer && (
            <div className="flex items-center gap-2 px-4 py-3 bg-blue-500/5 border border-blue-500/15 rounded-2xl">
              <span className="material-symbols-outlined text-blue-500 text-[18px]">verified</span>
              <div>
                <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Verified Partner</p>
                <p className="text-[9px] text-blue-400/70 font-medium">Catalog managed directly by store</p>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Catalog */}
        <div className="lg:col-span-3">
          <StoreCatalogView
            storeId={store.id}
            storeName={store.name}
            isVerified={store.isVerifiedRetailer}
          />
        </div>
      </div>
    </div>
  );
}
