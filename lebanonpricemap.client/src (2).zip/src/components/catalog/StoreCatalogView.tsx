import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { catalogApi } from '@/api/catalog.api';
import { CatalogDiscrepancyDialog } from '@/components/dialogs/CatalogDiscrepancyDialog';
import type { CatalogProduct } from '@/types/catalog.types';
import { cn } from '@/lib/utils';
import { useToastStore } from '@/store/useToastStore';
import { timeAgo } from '@/lib/utils';

interface StoreCatalogViewProps {
  storeId: string;
  storeName: string;
  isVerified: boolean;
}

const DAYS_STALE = 3;

function isStale(lastUpdatedAt: string): boolean {
  const daysSince = (Date.now() - new Date(lastUpdatedAt).getTime()) / (1000 * 60 * 60 * 24);
  return daysSince > DAYS_STALE;
}

const CATEGORY_ICONS: Record<string, string> = {
  Dairy: 'water_drop',
  Bakery: 'bakery_dining',
  Oil: 'opacity',
  Meat: 'kebab_dining',
  Grains: 'grain',
  Produce: 'nutrition',
  Fuel: 'local_gas_station',
  Beverages: 'local_drink',
};

function CatalogProductCard({
  cp,
  index,
  onReport,
}: {
  cp: CatalogProduct;
  index: number;
  onReport: (cp: CatalogProduct) => void;
}) {
  const effectivePrice = cp.isPromotion && cp.promoPriceLbp ? cp.promoPriceLbp : cp.officialPriceLbp;
  const stale = isStale(cp.lastUpdatedAt);
  const promoExpired = cp.isPromotion && cp.promoEndsAt && new Date(cp.promoEndsAt) < new Date();
  const icon = CATEGORY_ICONS[cp.productCategory] || 'inventory_2';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04 }}
      className={cn(
        'group relative bg-bg-surface border rounded-2xl p-5 transition-all hover:shadow-lg',
        !cp.isInStock
          ? 'border-red-400/20 bg-red-400/5 opacity-70'
          : stale
          ? 'border-amber-400/20'
          : 'border-border-primary/20 hover:border-primary/30'
      )}
    >
      {/* Badges row */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <div className={cn(
          'flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[9px] font-black uppercase tracking-widest',
          cp.isInStock
            ? 'bg-green-500/5 border-green-500/20 text-green-500'
            : 'bg-red-500/5 border-red-500/20 text-red-500'
        )}>
          <span className="material-symbols-outlined text-[11px]">{cp.isInStock ? 'check_circle' : 'remove_circle'}</span>
          {cp.isInStock ? 'In Stock' : 'Out of Stock'}
        </div>

        {cp.isPromotion && !promoExpired && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/10 border border-primary/20 text-[9px] font-black text-primary uppercase tracking-widest">
            <span className="material-symbols-outlined text-[11px]">local_offer</span>
            Promo
            {cp.promoEndsAt && <span className="opacity-70">· ends {timeAgo(cp.promoEndsAt)}</span>}
          </div>
        )}

        {stale && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/5 border border-amber-400/20 text-[9px] font-black text-amber-500 uppercase tracking-widest">
            <span className="material-symbols-outlined text-[11px]">schedule</span>
            Price may be stale
          </div>
        )}
      </div>

      {/* Product info */}
      <div className="flex items-start gap-4 mb-5">
        <div className="w-12 h-12 rounded-xl bg-bg-muted border border-border-soft flex items-center justify-center shrink-0">
          <span className="material-symbols-outlined text-[22px] text-text-muted">{icon}</span>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-black text-text-main text-base leading-tight mb-1 truncate">{cp.productName}</h3>
          <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">{cp.productCategory} · {cp.productUnit}</p>
        </div>
      </div>

      {/* Price block */}
      <div className="flex items-baseline gap-3 mb-5">
        <div>
          <p className="text-3xl font-black text-primary leading-none tabular-nums">
            {effectivePrice.toLocaleString()}
          </p>
          <p className="text-[9px] font-black text-text-muted uppercase tracking-[0.3em] mt-1">LBP</p>
        </div>
        {cp.isPromotion && cp.promoPriceLbp && !promoExpired && (
          <p className="text-sm font-bold text-text-muted line-through">
            {cp.officialPriceLbp.toLocaleString()}
          </p>
        )}
      </div>

      {/* Footer: staleness + report */}
      <div className="flex items-center justify-between pt-4 border-t border-border-soft">
        <p className="text-[9px] font-bold text-text-muted uppercase tracking-widest">
          Updated {timeAgo(cp.lastUpdatedAt)}
        </p>
        {cp.isInStock && (
          <button
            onClick={() => onReport(cp)}
            className="flex items-center gap-1.5 text-[9px] font-black text-text-muted uppercase tracking-widest hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
          >
            <span className="material-symbols-outlined text-[14px]">flag</span>
            Report discrepancy
          </button>
        )}
      </div>
    </motion.div>
  );
}

export function StoreCatalogView({ storeId, storeName, isVerified }: StoreCatalogViewProps) {
  const addToast = useToastStore(s => s.addToast);
  const [reportTarget, setReportTarget] = useState<CatalogProduct | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');

  const products = useMemo(() => catalogApi.getByStore(storeId), [storeId]);
  const categories = useMemo(() => {
    const cats = Array.from(new Set(products.map(p => p.productCategory)));
    return ['All', ...cats];
  }, [products]);

  const filtered = useMemo(() => {
    if (activeCategory === 'All') return products;
    return products.filter(p => p.productCategory === activeCategory);
  }, [products, activeCategory]);

  const inStockCount = products.filter(p => p.isInStock).length;

  if (!isVerified) {
    return (
      <div className="py-16 text-center border border-dashed border-border-primary/40 rounded-3xl bg-bg-surface/30">
        <span className="material-symbols-outlined text-border-primary/40 text-[56px] block mb-4">storefront</span>
        <h3 className="text-base font-black text-text-main mb-2">No Official Catalog</h3>
        <p className="text-sm text-text-muted max-w-xs mx-auto font-medium leading-relaxed">
          {storeName} is not yet a verified retailer partner. Community-reported prices may be available in the main search.
        </p>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="py-16 text-center border border-dashed border-border-primary/40 rounded-3xl bg-bg-surface/30">
        <span className="material-symbols-outlined text-border-primary/40 text-[56px] block mb-4">inventory_2</span>
        <h3 className="text-base font-black text-text-main mb-2">Catalog Empty</h3>
        <p className="text-sm text-text-muted font-medium">This store hasn't published any official prices yet.</p>
      </div>
    );
  }

  return (
    <div>
      {/* Stats bar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-black text-text-main">Official Catalog</h2>
          <span className="px-2.5 py-1 bg-green-500/5 border border-green-500/20 text-green-500 rounded-full text-[10px] font-black uppercase tracking-widest">
            {inStockCount}/{products.length} in stock
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] font-black text-primary uppercase tracking-widest">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
          Catalog-First
        </div>
      </div>

      {/* Category pills */}
      {categories.length > 2 && (
        <div className="flex gap-2 overflow-x-auto pb-4 hide-scrollbar mb-6">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                'px-4 py-1.5 rounded-full border text-[11px] font-bold whitespace-nowrap transition-all',
                activeCategory === cat
                  ? 'bg-primary text-white border-primary'
                  : 'bg-bg-surface text-text-muted border-border-primary hover:border-primary hover:text-primary'
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        {filtered.map((cp, i) => (
          <CatalogProductCard
            key={cp.id}
            cp={cp}
            index={i}
            onReport={setReportTarget}
          />
        ))}
      </div>

      {/* Report dialog */}
      {reportTarget && (
        <CatalogDiscrepancyDialog
          product={reportTarget}
          storeId={storeId}
          isOpen={!!reportTarget}
          onClose={() => setReportTarget(null)}
          onSubmitted={() => {
            addToast('Report submitted — admin will review it shortly.', 'success');
          }}
        />
      )}
    </div>
  );
}
